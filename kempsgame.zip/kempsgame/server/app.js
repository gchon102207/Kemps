const express = require('express');
const cors = require('cors');
const path = require('path');
const bodyParser = require('body-parser');
const http = require('http');
const socketIo = require('socket.io'); 

const app = express();

app.use("/client", express.static(path.resolve(__dirname + "/../client/")));

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    next();
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use("/client", express.static(path.resolve(__dirname + "/../client/")));

// Page listeners (routers)
var router = require('./router.js');
router(app);

// Service listeners (database)
var services = require('./services.js');
services(app);

// Create an HTTP server for both Express and Socket.IO
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// Handle socket connections
const users = {}; // Store users with their socket IDs
const lobbies = new Set(); // Store active lobby codes

io.on('connection', (socket) => {
    console.log('A user connected:', socket.id);
    
    socket.on('setUsername', (username) => {
        if (!users[socket.id]) {
            users[socket.id] = username; // Map the current socket to the username
            console.log(`User set: ${username} for socket: ${socket.id}`);
        }
    });

    socket.on('createLobby', ({ username }) => {
        users[socket.id] = username;
        const lobbyCode = generateLobbyCode();
        lobbies.add(lobbyCode); // Add the new lobby code to the set of active lobbies
        socket.join(lobbyCode);
        io.to(lobbyCode).emit('lobbyCreated', { code: lobbyCode, users: getUsersInLobby(lobbyCode) });
    });

    socket.on('joinLobby', ({ lobbyCode, username }) => {
        if (lobbies.has(lobbyCode)) {
            const clients = io.sockets.adapter.rooms.get(lobbyCode) || new Set();
    
            // Count active users
            const activeUsers = Array.from(clients).filter(clientId => users[clientId]);
    
            if (activeUsers.length >= 4) {
                socket.emit('error', { message: 'Lobby is full' });
            } else {
                // Ensure no duplicate joins
                if (!clients.has(socket.id)) {
                    users[socket.id] = username;
                    socket.join(lobbyCode);
    
                    // Notify the user and the lobby
                    socket.emit('joinedLobby', { code: lobbyCode });
                    io.to(lobbyCode).emit('userJoined', { users: getUsersInLobby(lobbyCode) });
                }
            }
        } else {
            socket.emit('error', { message: 'Lobby code does not exist' });
        }
    });    

    socket.on('disconnect', () => {
        const username = users[socket.id];
        delete users[socket.id]; // Only remove the disconnected user
    
        // Notify other users in the room
        for (const lobbyCode of lobbies) {
            const room = io.sockets.adapter.rooms.get(lobbyCode);
            if (room?.has(socket.id)) {
                io.to(lobbyCode).emit('userLeft', { username, users: getUsersInLobby(lobbyCode) });
            }
        }
    
        console.log('User disconnected:', socket.id);
    });
});

function generateLobbyCode() {
    return Math.random().toString(36).substr(2, 6).toUpperCase();
}

function getUsersInLobby(lobbyCode) {
    const clients = io.sockets.adapter.rooms.get(lobbyCode) || new Set();
    return Array.from(clients).map(clientId => users[clientId]);
}

const port = 5000;
server.listen(port, (err) => {
    if (err) throw err;
    console.log("Listening on port: " + port);
});